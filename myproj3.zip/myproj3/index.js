require('dotenv').config();

const express =  require('express')
const connetDB = require('./db/connect')

const product_routes = require('./routes/product')
const app = express()


app.get("/",(req,res)=>{
    res.send("Hi i am mohit")
})

app.use("/api/prducts",product_routes)
app.use(express.json());



const start = async ()=>{
    try{
         
        await connetDB(process.env.MONGODB_URL);
        app.listen(4000,()=>{
            console.log('server started.... yes i am connected')
        })
    }
    catch(err){
        console.log(err)
    }
}

start()